%% Section D. Clustering
% Author: Yibing Liu, Junyu Yan
%--------------------------------------------------------------------------

clc;clear;close all;
%% Data processing and initialization
% Load data
load('F0_PVT.mat');
load('F0_Electrode.mat');
% Initialization
nObj = 6;
% The object name
object_name = {'acry','black','car','flour','kitchen','steel'};
% The color for objects
color = {'r','g','b','c','m','k'};
% Marker type
markType = {'o','p','>','d','^','s'};
% Number of dimensions for PVT data
nDim = 3;
% Number of dimensions for electrode data
nDim_Elec = 19;
% Number of trials
nTrial = 10;
% The max iteration
iter_max = 1000;
% The matching threshold
threshold = 0.00001;
% The data matrix
data_PVT = zeros(nDim,nObj*nTrial);
% Change data into 3*60 dimentions, where each row represents pressure,
% vibraion and temperature, respectively.
for iObj = 1:nObj
    data = eval([object_name{iObj},'_PVT']);
    data_PVT(:,(iObj-1)*nTrial+1:iObj*nTrial) = data; 
end
%% Standarize the data by substracting mean and being divided by standard variance 
for iDim = 1:nDim
    data_PVT(iDim,:)=(data_PVT(iDim,:)-mean(data_PVT(iDim,:)))/std(data_PVT(iDim,:));
end
%% Process electrode data with PCA
% make the dataset
data_Elec = zeros(nDim_Elec,nObj*nTrial);
for iObj = 1:nObj
    data = eval([object_name{iObj},'_Electrode']);
    data_Elec(:,(iObj-1)*nTrial+1:iObj*nTrial) = data; 
end
% Standarize the data by substracting mean and being divided by standard variance 
for iDim = 1:nDim_Elec
    data_Elec(iDim,:)=(data_Elec(iDim,:)-mean(data_Elec(iDim,:)))/std(data_Elec(iDim,:));
end
% Obtain the covariance matrix
cov_Elec = cov(data_Elec');
% Obtain the eigenvalues and eigenvectors
[eigvec_Elec,eigval_Elec] = eig(cov_Elec);
% Sort the eigenvalue and choose the top three principal components with
% largest variance
[~,Index_Elec] = maxk(diag(eigval_Elec),3);
feature_Elec = eigvec_Elec(:,Index_Elec);
% Project the data; get the 3D data
reduced_Elec = feature_Elec.'*data_Elec;

%% Question 1.a
% Use K-means Clustering
% Choose k random centroids
% Find ranges for pressure, vibration and temperature axis
P_min = min(data_PVT(1,:));
V_min = min(data_PVT(2,:));
T_min = min(data_PVT(3,:));
P_max = max(data_PVT(1,:));
V_max = max(data_PVT(2,:));
T_max = max(data_PVT(3,:));
% Generate centoriod
parameter_name = {'P','V','T'};
% The centroid matrix
Centriod = zeros(nDim,nObj);
for iObj = 1:nObj
    for iDim = 1:nDim
        parameter = [eval([parameter_name{iDim},'_min']),eval([parameter_name{iDim},'_max'])];
        Centriod(iDim,iObj) = parameter(1)+(parameter(2)-parameter(1))*rand();
    end
end
% Using Euclidean distance matrix
% Obtain the total number of points
[~,nPoints] = size(data_PVT);
% Initialize the distance matrix 
dist_Eu = zeros(nObj,1);
% Intialize the group matrix
group = zeros(1,nPoints);
% Initialize the iteration times
iter = 0;
% Initialize the group mean
group_mean = zeros(nDim,nObj);
% The parameter to indicate whether need to rechoose the centriod
re_centriod = 0;
cluster_index = zeros(1,nPoints);
while 1
    % Initialize the clustered data matrix
    clustered_Eu = cell(nObj,1);
    % Calculate the distance between all points and centroids
    for iPoint = 1:nPoints
        for iObj = 1:nObj
            dist_Eu(iObj) = norm(data_PVT(:,iPoint)-Centriod(:,iObj));
        end
        [~,group_index] = min(dist_Eu);
        cluster_index(iPoint) = group_index;
        clustered_Eu{group_index} = [clustered_Eu{group_index},data_PVT(:,iPoint)];
    end
    for iObj = 1:nObj
        if isempty(clustered_Eu{iObj})
            disp(['Bad chioce of centriod, need choose again'])
            return;
        end
    end
    % Calculate the each group mean and updata the centriod
    for iObj = 1:nObj
        group_mean(:,iObj) = mean(clustered_Eu{iObj,1},2);
    end
    if sqrt(sum((Centriod-group_mean).^2))<0.0001
       break;
    else
       Centriod = group_mean;
    end
    
    iter = iter+1;
    if iter > iter_max
        disp(['Dose not convergence']);
        break;
    end
end

% Plot the classified result 
figure(1);
subplot(1,2,1);
for iObj = 1:nObj
    x_axis = data_PVT(1,(iObj-1)*nTrial+1:iObj*nTrial);
    y_axis = data_PVT(2,(iObj-1)*nTrial+1:iObj*nTrial);
    z_axis = data_PVT(3,(iObj-1)*nTrial+1:iObj*nTrial);
    cluster = cluster_index(1,(iObj-1)*nTrial+1:iObj*nTrial);
    for iPoint = 1:nTrial
        scatter3(x_axis(iPoint),y_axis(iPoint),z_axis(iPoint),color{iObj},markType{cluster(iPoint)},'filled');
        hold on;
    end
end
axis([-2 2 -2 2]);
axis square;
set(gca,'fontsize',12);
grid on;
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
title('Classified groups with Euclidean');
%% Question 1.c
% Using Manhattan distance matrix
% Obtain the total number of points
[~,nPoints] = size(data_PVT);
% Initialize the distance matrix 
dist_Ma = zeros(nObj,1);
% Intialize the group matrix
group = zeros(1,nPoints);
% Initialize the iteration times
iter = 0;
% Initialize the group mean
group_mean = zeros(nDim,nObj);
% The parameter to indicate whether need to rechoose the centriod
re_centriod = 0;
index_Ma=zeros(1,nPoints);
while 1
    % Initialize the clustered data matrix
    clustered_Ma = cell(nObj,1);
    % Calculate the distance between all points and centroids
    for iPoint = 1:nPoints
        for iObj = 1:nObj
            dist_Ma(iObj) = sum(abs(data_PVT(:,iPoint)-Centriod(:,iObj)));
        end
        [~,group_index] = min(dist_Ma);
        index_Ma(iPoint) = group_index;
        clustered_Ma{group_index} = [clustered_Ma{group_index},data_PVT(:,iPoint)];
    end
    for iObj = 1:nObj
        if isempty(clustered_Ma{iObj})
            disp(['Bad chioce of centriod, need choose again'])
            return;
        end
    end
    % Calculate the each group mean and updata the centriod
    for iObj = 1:nObj
        group_mean(:,iObj) = mean(clustered_Ma{iObj,1},2);
    end
    if sum(Centriod-group_mean)<0.0001
       break;
    else
       Centriod = group_mean;
    end
    
    iter = iter+1;
    if iter > iter_max
        disp(['Dose not convergence']);
        break;
    end
end
subplot(1,2,2);
for iObj = 1:nObj
    x_axis = data_PVT(1,(iObj-1)*nTrial+1:iObj*nTrial);
    y_axis = data_PVT(2,(iObj-1)*nTrial+1:iObj*nTrial);
    z_axis = data_PVT(3,(iObj-1)*nTrial+1:iObj*nTrial);
    cluster = index_Ma(1,(iObj-1)*nTrial+1:iObj*nTrial);
    for iPoint = 1:nTrial
        scatter3(x_axis(iPoint),y_axis(iPoint),z_axis(iPoint),color{iObj},markType{cluster(iPoint)},'filled');
        hold on;
    end
end
axis([-2 2 -2 2]);
axis square;
set(gca,'fontsize',12);
grid on;
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
title('Classified groups with Manhattan');
%% Question 2.a
% get training data and test data
object_species=repelem(object_name,6);
Training_data = [];
Test_data = [];
for iObj=1:nObj
    object_set = reduced_Elec(:,(iObj-1)*nTrial+1:iObj*nTrial);
    nRandom=randperm(nTrial,size(object_set,2)*0.6);
    Training_data=[Training_data,object_set(:,nRandom)];
    object_set(:,nRandom) = [];
    Test_data = [Test_data, object_set]; 
end
% Plot the OOB error
figure(2);
% rng('default');
% Here we set 100 trees to see the relationship between the OOB error and
% the number of the tree
Tree=TreeBagger(100,Training_data',object_species,'OOBPrediction','On','Method','classification');
oobErrorBaggedEnsemble = oobError(Tree);
plot(oobErrorBaggedEnsemble)
xlabel('Number of the Tree');
ylabel('Out-of-bag Error');
grid on;
title('The relationship between OOB errors and the number of trees ');
%% Question 2.b
% See the two of the generated decision trees
view(Tree.Trees{1},'Mode','graph');
view(Tree.Trees{2},'Mode','graph');
%% Question 2.c
new_Tree=TreeBagger(100,Training_data',object_species,'OOBPrediction','On','Method','classification');
[Predicted_label,~,~]=predict(new_Tree,Test_data');
% The true labels
True_label=repelem(object_name,4)';
C = confusionmat(True_label,Predicted_label);
figure(3);
confusionchart(C);
xlabel('Predicted Label');
ylabel('True Label');