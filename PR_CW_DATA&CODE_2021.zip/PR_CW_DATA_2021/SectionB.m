%% Section B. Principle component analysis
% Author: Yibing Liu, Junyu Yan
%--------------------------------------------------------------------------

clc;clear;close all;
%% Data processing and initialization
% Load data
load('F0_PVT.mat');
% Initialization
nObj = 6;
% The object name
object_name = {'acry','black','car','flour','kitchen','steel'};
% The color for objects
color = {'r','g','b','c','m','k'};
% Number of dimensions
nDim = 3;
% Number of trials
nTrial = 10;
% The data matrix
data_PVT = zeros(nDim,nObj*nTrial);
% Change data into 3*60 dimentions, where each row represents pressure,
% vibraion and temperature, respectively.
for iObj = 1:nObj
    data = eval([object_name{iObj},'_PVT']);
    data_PVT(:,(iObj-1)*nTrial+1:iObj*nTrial) = data; 
end

%% Standarize the data by substracting mean and being divided by standard variance 
for iDim = 1:nDim
    data_PVT(iDim,:)=(data_PVT(iDim,:)-mean(data_PVT(iDim,:)))/std(data_PVT(iDim,:));
end

%% Question 1.a
% obtain the covariance matrix, eigenvalues and eigenvectors for the data 
Cov_PVT = cov(data_PVT');
[eigenvectors,eigenvalues] = eig(Cov_PVT);

%% Question 1.b
% Replot the standarized data
figure;
subplot(1,2,1);
for iObj = 1:nObj
    x_axis = data_PVT(1,(iObj-1)*nTrial+1:iObj*nTrial);
    y_axis = data_PVT(2,(iObj-1)*nTrial+1:iObj*nTrial);
    z_axis = data_PVT(3,(iObj-1)*nTrial+1:iObj*nTrial);
    scatter3(x_axis,y_axis,z_axis,color{iObj},'filled');
    hold on;
end
plot3([0 eigenvectors(1,1)], [0 eigenvectors(2,1)], [0 eigenvectors(3,1)],'color',[0.5,0,0],'linewidth', 2);
hold on;
plot3([0 eigenvectors(1,2)], [0 eigenvectors(2,2)], [0 eigenvectors(3,2)],'color',[1,0.5,0],'linewidth', 2);
hold on;
plot3([0 eigenvectors(1,3)], [0 eigenvectors(2,3)], [0 eigenvectors(3,3)],'color',[0.667,0.667,1],'linewidth', 2);
hold on;
axis([-3 3 -3 3 -3 3]);
axis square;
set(gca,'fontsize',12);
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
title('The standarized PVT with principle compomemts');

%% Question 1.c
% Find the feature vectors
[~,Index]=maxk(diag(eigenvalues),2);
feature_vect = eigenvectors(:,Index);
% Reduce to 2D
reduced_data = feature_vect'*data_PVT;
feature_vect = feature_vect.'*feature_vect;
% Plot the reduced data
subplot(1,2,2);
for iObj = 1:nObj
    x_axis = reduced_data(1,(iObj-1)*nTrial+1:iObj*nTrial);
    y_axis = reduced_data(2,(iObj-1)*nTrial+1:iObj*nTrial);
    scatter(x_axis,y_axis,color{iObj},'filled');
    hold on;
end
plot([0 feature_vect(1,1)], [0 feature_vect(2,1)],'color',[0.5,0,0],'linewidth', 2);
hold on;
plot([0 feature_vect(1,2)], [0 feature_vect(2,2)], 'color',[1,0.5,0],'linewidth', 2);
grid on;
axis([-3.5 3.5 -3.5 3.5]);
axis square;
xlabel('PC1');
ylabel('PC2');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
title('Projected PVT onto 2D principal components');
set(gca,'fontsize',12);

%% Question 1.d
% Initialization
% The number of principle components
N_PC = size(eigenvectors,2);
% The y axis for different PC 
y_PC = zeros(N_PC,nTrial);

% Find the feature vectors
[~,Index_1D]=maxk(diag(eigenvalues),3);
feature_1D = eigenvectors(:,Index_1D);
% Reduce to 2D
reduced_1D = feature_1D.'*data_PVT; 
% Project into 1D data and plot
figure;
for iIndex = 1:N_PC
    y_PC(iIndex,:) =iIndex*1;
    for iObj = 1:nObj
        x_axis = reduced_1D(iIndex,(iObj-1)*nTrial+1:iObj*nTrial);
        y_axis = y_PC(iIndex,:);
        scatter(x_axis,y_axis,color{iObj},'filled');
        hold on;
    end
end
grid on;
ylabel('PC1                           PC2                             PC3');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
title('Projected PVT onto 1D principal component');
set(gca,'fontsize',12);

%% Question 2.a
% Initialization
% The dimension of electrode data
nDim_Elec = 19;
% Load data
load('F0_Electrode.mat');
% The data matrix
data_Elec = zeros(nDim_Elec,nObj*nTrial);
% Change data into 19*60 dimentions, where each row represents pressure,
% vibraion and temperature, respectively.
for iObj = 1:nObj
    data = eval([object_name{iObj},'_Electrode']);
    data_Elec(:,(iObj-1)*nTrial+1:iObj*nTrial) = data; 
end
% Standarize the data by substracting mean and being divided by standard variance 
for iDim = 1:nDim_Elec
    data_Elec(iDim,:)=(data_Elec(iDim,:)-mean(data_Elec(iDim,:)))/std(data_Elec(iDim,:));
end
% Obtain the covariance matrix
cov_Elec = cov(data_Elec');
% Obtain the eigenvalues and eigenvectors
[eigvec_Elec,eigval_Elec] = eig(cov_Elec);
% Create a scree plot
figure;
x_axis = 1:1:nDim_Elec;
y_axis = sort(diag(eigval_Elec),'descend');
plot(x_axis,y_axis,'o-');
grid on;grid minor;
xlabel('Component number');
ylabel('Variance');
title('Scree plot of electrode');
set(gca,'fontsize',12);

%% Question 2.b
% Sort the eigenvalue and choose the top three principal components with
% largest variance
[~,Index_Elec] = maxk(diag(eigval_Elec),3);
feature_Elec = eigvec_Elec(:,Index_Elec);
% Project the data
reduced_Elec = feature_Elec.'*data_Elec;
% Project the principle component
feature_Elec = feature_Elec.'*feature_Elec;
%% Plot the data
figure;
for iObj = 1:nObj
    x_axis = reduced_Elec(1,(iObj-1)*nTrial+1:iObj*nTrial);
    y_axis = reduced_Elec(2,(iObj-1)*nTrial+1:iObj*nTrial);
    z_axis = reduced_Elec(3,(iObj-1)*nTrial+1:iObj*nTrial);
    scatter3(x_axis,y_axis,z_axis,color{iObj},'filled');
    hold on;
end
plot3([0 feature_Elec(1,1)], [0 feature_Elec(2,1)], [0 feature_Elec(3,1)],'color',[0.5,0,0],'linewidth', 2);
hold on;
plot3([0 feature_Elec(1,2)], [0 feature_Elec(2,2)], [0 feature_Elec(3,2)],'color',[1,0.5,0],'linewidth', 2);
hold on;
plot3([0 feature_Elec(1,3)], [0 feature_Elec(2,3)], [0 feature_Elec(3,3)],'color',[0.667,0.667,1],'linewidth', 2);
axis([-6.5 6.5 -6.5 6.5 -3 3]);
axis square;
grid on;
xlabel('PC1');
ylabel('PC2');
zlabel('PC3');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
title('Projected Electrode onto 3D prociple components');
set(gca,'fontsize',12);