%% Section C. Linear discriminant analysis
% Author: Yibing Liu, Junyu Yan
%--------------------------------------------------------------------------
% The first three parts process the data with LDA, 
clc;clear;close all;
%% Standarize the data
%  Load data
load('F0_PVT.mat');
% Dimension: apply LDA to 2D PVT data or 3D data
nDim_2D=2;
nDim_3D=3;
% Number of trials
nTrial=10;
% Make the datas of the black foam and the car sponge.
data_PV=[black_PVT(1:2,:),car_PVT(1:2,:)];
data_PT=[black_PVT([1 3],:),car_PVT([1 3],:)];
data_VT=[black_PVT(2:3,:),car_PVT(2:3,:)];
data_PVT=[black_PVT(1:3,:),car_PVT(1:3,:)];
%  Sandardize the data
% For Pressure and Vibration
for iDim=1:nDim_2D
   data_PV(iDim,:)=(data_PV(iDim,:)-mean(data_PV(iDim,:)))/std(data_PV(iDim,:)); 
end
% For Pressure and Temperature
for iDim=1:nDim_2D
   data_PT(iDim,:)=(data_PT(iDim,:)-mean(data_PT(iDim,:)))/std(data_PT(iDim,:)); 
end
% For Vibration and Temperature
for iDim=1:nDim_2D
   data_VT(iDim,:)=(data_VT(iDim,:)-mean(data_VT(iDim,:)))/std(data_VT(iDim,:)); 
end
for iDim=1:nDim_3D
   data_PVT(iDim,:)=(data_PVT(iDim,:)-mean(data_PVT(iDim,:)))/std(data_PVT(iDim,:)); 
end
%%  Calculate Group Mean
% For Pressure and Vibration
m1_PV=mean(data_PV(1:nDim_2D,1:nTrial),2);
m2_PV=mean(data_PV(1:nDim_2D,1+nTrial:2*nTrial),2);
mean_total_PV=m1_PV+m2_PV;
% For Pressure and Temperature
m1_PT=mean(data_PT(1:nDim_2D,1:nTrial),2);
m2_PT=mean(data_PT(1:nDim_2D,1+nTrial:2*nTrial),2);
mean_total_PT=m1_PT+m2_PT;
% For Vibration and Temperature
m1_VT=mean(data_VT(1:nDim_2D,1:nTrial),2);
m2_VT=mean(data_VT(1:nDim_2D,1+nTrial:2*nTrial),2);
mean_total_VT=m1_VT+m2_VT;
% For PVT data
mean_black=mean(data_PVT(1:nDim_3D,1:nTrial),2);
mean_car=mean(data_PVT(1:nDim_3D,1+nTrial:2*nTrial),2);
mean_tatal=mean_car+mean_black;
%% Get Scatter Matrices
% Scatter matrices within and between class
% For Pressure and Vibration
Sw1_PV=(data_PV(1:nDim_2D,1:nTrial)-m1_PV)*(data_PV(1:nDim_2D,1:nTrial)-m1_PV)';
Sw2_PV=(data_PV(1:nDim_2D,1+nTrial:2*nTrial)-m2_PV)*(data_PV(1:nDim_2D,1+nTrial:2*nTrial)-m2_PV)';
Sw_PV=Sw1_PV+Sw2_PV;
Sb_PV=(m1_PV-m2_PV)*(m1_PV-m2_PV)';
Scatter_matrix_PV=pinv(Sw_PV)*Sb_PV;
% For Pressure and Temperature
Sw1_PT=(data_PT(1:nDim_2D,1:nTrial)-m1_PT)*(data_PT(1:nDim_2D,1:nTrial)-m1_PT)';
Sw2_PT=(data_PT(1:nDim_2D,1+nTrial:2*nTrial)-m2_PT)*(data_PT(1:nDim_2D,1+nTrial:2*nTrial)-m2_PT)';
Sw_PT=Sw1_PT+Sw2_PT;
Sb_PT=(m1_PT-m2_PT)*(m1_PT-m2_PT)';
Scatter_matrix_PT=pinv(Sw_PT)*Sb_PT;
% For Vibration and Temperature
Sw1_VT=(data_VT(1:nDim_2D,1:nTrial)-m1_VT)*(data_VT(1:nDim_2D,1:nTrial)-m1_VT)';
Sw2_VT=(data_VT(1:nDim_2D,1+nTrial:2*nTrial)-m2_VT)*(data_VT(1:nDim_2D,1+nTrial:2*nTrial)-m2_VT)';
Sw_VT=Sw1_VT+Sw2_VT;
Sb_VT=(m1_VT-m2_VT)*(m1_VT-m2_VT)';
Scatter_matrix_VT=pinv(Sw_VT)*Sb_VT;
% For 3D PVT data
Sw_black=(data_PVT(1:nDim_3D,1:nTrial)-mean_black)*(data_PVT(1:nDim_3D,1:nTrial)-mean_black)';
Sw_car=(data_PVT(1:nDim_3D,1+nTrial:2*nTrial)-mean_car)*(data_PVT(1:nDim_3D,1+nTrial:2*nTrial)-mean_car)';
Sw=Sw_black+Sw_car;
Sb=(mean_black-mean_car)*(mean_black-mean_car)';
Scatter_matrix=pinv(Sw)*Sb;
%%  Take the Eigenvalues and Eigenvectors
[eig_vector_PV,eig_value_PV]=eig(Scatter_matrix_PV);
[eig_vector_PT,eig_value_PT]=eig(Scatter_matrix_PT);
[eig_vector_VT,eig_value_VT]=eig(Scatter_matrix_VT);
% Find the largest eigenvalues and its eigenvector
% For Pressure and Vibration
[~,position_PV]=sort(diag(eig_value_PV),'descend');
feature_PV=eig_vector_PV(:,position_PV(1));
% For Pressure and Temperature
[~,position_PT]=sort(diag(eig_value_PT),'descend');
feature_PT=eig_vector_PT(:,position_PT(1));
% For Vibration and Temperature
[~,position_VT]=sort(diag(eig_value_VT),'descend');
feature_VT=eig_vector_VT(:,position_VT(1));
% For 3D PVT data
[eig_vector,eig_value]=eig(Scatter_matrix);
[~,position]=sort(diag(eig_value),'descend');
feature_first=eig_vector(:,position(1));
feature_second=eig_vector(:,position(2));
%% Question 1.a
figure(1);
subplot(2,3,1);
% For Pressure and Vibration
slope=[(feature_PV(2)-0)/(feature_PV(1)-0);(feature_PT(2)-0)/(feature_PT(1)-0);(feature_VT(2)-0)/(feature_VT(1)-0)];
bias=0;
scatter(data_PV(1,1:nTrial),data_PV(2,1:nTrial),'g');
hold on;
scatter(data_PV(1,1+nTrial:2*nTrial),data_PV(2,1+nTrial:2*nTrial),'b');
hold on;
scatter(m1_PV(1),m1_PV(2),80,'g','filled');
hold on;
scatter(m2_PV(1),m2_PV(2),80,'b','filled');
hold on;
% Plot LDA line and disctimination line
hline1_PV=refline(1*slope(1),bias);
hline1_PV.Color='k';
hline1_PV.LineStyle='-';
hline1_PV.LineWidth=1;
hold on;
hline2_PV=refline(-1/slope(1),bias);
hline2_PV.Color='r';
hline2_PV.LineWidth=1;
hline2_PV.LineStyle=':';
grid on;
axis([-3 3 -3 3]);
axis square;
set(gca,'FontSize',12);
xlabel('Pressure');
ylabel('Vibration');
legend('black foam','car sponge','mean for black foam','mean for car sponge','LDA line','disctimination line');
title('2D LDA for Pressure and Vibration');
% For Pressure and Temperature
subplot(2,3,2);
scatter(data_PT(1,1:nTrial),data_PT(2,1:nTrial),'g');
hold on;
scatter(data_PT(1,1+nTrial:2*nTrial),data_PT(2,1+nTrial:2*nTrial),'b');
hold on;
scatter(m1_PT(1),m1_PT(2),80,'g','filled');
hold on;
scatter(m2_PT(1),m2_PT(2),80,'b','filled');
hold on;
% Plot LDA line and disctimination line
hline1_PT=refline(1*slope(2),bias);
hline1_PT.Color='k';
hline1_PT.LineStyle='-';
hline1_PT.LineWidth=1;
hold on;
hline2_PT=refline(-1/slope(2),bias);
hline2_PT.Color='r';
hline2_PT.LineWidth=1;
hline2_PT.LineStyle=':';
grid on;
axis([-3 3 -3 3]);
axis square;
title('2D LDA for Pressure and Temperature')
xlabel('Pressure');
ylabel('Temperature');
set(gca,'FontSize',12);
% For Vibration and Temperature
subplot(2,3,3);
scatter(data_VT(1,1:nTrial),data_VT(2,1:nTrial),'g');
hold on;
scatter(data_VT(1,1+nTrial:2*nTrial),data_VT(2,1+nTrial:2*nTrial),'b');
hold on;
scatter(m1_VT(1),m1_VT(2),80,'g','filled');
hold on;
scatter(m2_VT(1),m2_VT(2),80,'b','filled');
hold on;
% Plot LDA line and disctimination line
hline1_VT=refline(1*slope(3),bias);
hline1_VT.Color='k';
hline1_VT.LineStyle='-';
hline1_VT.LineWidth=1;
hold on;
hline2_VT=refline(-1/slope(3),bias);
hline2_VT.Color='r';
hline2_VT.LineWidth=1;
hline2_VT.LineStyle=':';
grid on;
axis([-3 3 -3 3]);
axis square;
xlabel('Vibration');
ylabel('Temperature');
title('2D LDA for Vibration and Temperature')
set(gca,'FontSize',12);
% For Pressure and Vibration
subplot(2,3,4);
project_PV=feature_PV'*data_PV;
m1_PV_1D=feature_PV'*m1_PV;
m2_PV_1D=feature_PV'*m2_PV;
scatter(project_PV(1,1:nTrial),zeros(1,10),'g','filled');
hold on;
scatter(project_PV(1,1+nTrial:2*nTrial),zeros(1,10),'b','filled');
grid on;
scatter(m1_PV_1D,0,180,'g','h','filled');
hold on;
scatter(m2_PV_1D,0,180,'b','h','filled');
hold on
line([0 0],[-2 2],'linestyle','--', 'Color','r', 'LineWidth', 2);
ylabel('LD1');
legend('black foam','car sponge','mean for black foam','mean for car sponge','disctimination line');
title('1D LDA for Pressure and Vibration');
set(gca,'FontSize',12);
% For Pressure and Temperature
subplot(2,3,5);
project_PT=feature_PT'*data_PT;
m1_PT_1D=feature_PT'*m1_PT;
m2_PT_1D=feature_PT'*m2_PT;
scatter(project_PT(1,1:nTrial),zeros(1,10),'g','filled');
hold on;
scatter(project_PT(1,1+nTrial:2*nTrial),zeros(1,10),'b','filled');
grid on;
scatter(m1_PT_1D,0,180,'g','h','filled');
hold on;
scatter(m2_PT_1D,0,180,'b','h','filled');
hold on
line([0 0],[-2 2],'linestyle','--', 'Color','r', 'LineWidth', 2);
ylabel('LD1');
title('1D LDA for Pressure and Temperature');
set(gca,'FontSize',12);
% For Vibration and Temperature
subplot(2,3,6);
project_VT=feature_VT'*data_VT;
m1_VT_1D=feature_VT'*m1_VT;
m2_VT_1D=feature_VT'*m2_VT;
scatter(project_VT(1,1:nTrial),zeros(1,10),'g','filled');
hold on;
scatter(project_VT(1,1+nTrial:2*nTrial),zeros(1,10),'b','filled');
grid on;
scatter(m1_VT_1D,0,180,'g','h','filled');
hold on;
scatter(m2_VT_1D,0,180,'b','h','filled');
hold on
line([0 0],[-2 2],'linestyle','--', 'Color','r', 'LineWidth', 2);
ylabel('LD1');
title('1D LDA for Vibration and Temperature');
set(gca,'FontSize',12);

%% Question 1.b
figure(2);
% get the coefficients of the plane (Multiply 2 to make the plane bigger)
X=[feature_first(1),feature_second(1),-feature_first(1),-feature_second(1)];X=2*X;
Y=[feature_first(2),feature_second(2),-feature_first(2),-feature_second(2)];Y=2*Y;
Z=[feature_first(3),feature_second(3),-feature_first(3),-feature_second(3)];Z=2*Z;
% 3D data LDA, in one view
subplot(2,2,1);
scatter3(mean_black(1),mean_black(2),mean_black(3),180,'g','h','filled');
view([60,15])
hold on
scatter3(mean_car(1),mean_car(2),mean_car(3),180,'b','h','filled');
hold on;
scatter3(data_PVT(1,1:nTrial),data_PVT(2,1:nTrial),data_PVT(3,1:nTrial),'g','filled')
hold on;
scatter3(data_PVT(1,1+nTrial:2*nTrial),data_PVT(2,1+nTrial:2*nTrial),data_PVT(3,1+nTrial:2*nTrial),'b','filled')
hold on;
line1=plot3([-feature_first(1)*2,feature_first(1)*2],[-feature_first(2)*2,feature_first(2)*2],[-feature_first(3)*2,feature_first(3)*2]);
line1.Color='red';
line1.LineWidth=1;
line1.LineStyle='-';
hold on;
line2=plot3([-feature_second(1)*2,feature_second(1)*2],[-feature_second(2)*2,feature_second(2)*2],[-feature_second(3)*2,feature_second(3)*2]);
line2.Color='green';
line2.LineWidth=1;
line2.LineStyle='--';
hold on;
patch('X',X,'Y',Y,'Z',Z,'FaceAlpha','0.5');
hold on;
scatter3(0,0,0,'filled','k')
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
set(gca,'FontSize',15);
legend('Mean for black','Mean for car','Ten trials for black','Ten trials for car','LD1','LD2','hyperplane')
% 3D data in other view
subplot(2,2,2);
scatter3(mean_black(1),mean_black(2),mean_black(3),180,'g','h','filled');
view([-40,40])
hold on
scatter3(mean_car(1),mean_car(2),mean_car(3),180,'b','h','filled');
hold on;
scatter3(data_PVT(1,1:nTrial),data_PVT(2,1:nTrial),data_PVT(3,1:nTrial),'g','filled')
hold on;
scatter3(data_PVT(1,1+nTrial:2*nTrial),data_PVT(2,1+nTrial:2*nTrial),data_PVT(3,1+nTrial:2*nTrial),'b','filled')
hold on;
line1=plot3([-feature_first(1)*2,feature_first(1)*2],[-feature_first(2)*2,feature_first(2)*2],[-feature_first(3)*2,feature_first(3)*2]);
line1.Color='red';
line1.LineWidth=1;
line1.LineStyle='-';
hold on;
line2=plot3([-feature_second(1)*2,feature_second(1)*2],[-feature_second(2)*2,feature_second(2)*2],[-feature_second(3)*2,feature_second(3)*2]);
line2.Color='green';
line2.LineWidth=1;
line2.LineStyle='--';
hold on;
patch('X',X,'Y',Y,'Z',Z,'FaceAlpha','0.5');
hold on;
scatter3(0,0,0,'filled','k')
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
set(gca,'FontSize',15);
% 2D class separation
feature=[feature_first,feature_second];
mean_black_2D=feature'*mean_black;
mean_car_2D=feature'*mean_car;
subplot(2,2,3);
scatter(mean_black_2D(1),mean_black_2D(2),180,'g','h','filled');
hold on;
scatter(mean_car_2D(1),mean_car_2D(2),180,'b','h','filled');
hold on;
feature=[feature_first,feature_second];
project_2D=feature'*data_PVT;
scatter(project_2D(1,1:nTrial),project_2D(2,1:nTrial),'g','filled');
hold on;
scatter(project_2D(1,1+nTrial:2*nTrial),project_2D(2,1+nTrial:2*nTrial),'b','filled');
grid on;
hold on;
line([0 0],[-2 2],'linestyle','--', 'Color','g', 'LineWidth', 2)
xlabel('LD1');  
ylabel('LD2');
% set(gca,'fontsize','18');
set(gca,'FontSize',15);
title('Class separation for 2D');
legend('Mean for black','Mean for car','Project for black','Project for car')
% 1D class separation
mean_black_1D=feature_first'*mean_black;
mean_car_1D=feature_first'*mean_car;
project_1D=feature_first'*data_PVT;
subplot(2,2,4);
scatter(mean_black_1D,0,180,'g','h','filled');
hold on;
scatter(mean_car_1D,0,180,'b','h','filled');
hold on
scatter(project_1D(1,1:nTrial),zeros(1,10),'g','filled');
hold on;
scatter(project_1D(1,1+nTrial:2*nTrial),zeros(1,10),'b','filled');
grid on;
line([0 0],[-2 2],'linestyle','--', 'Color','g', 'LineWidth', 2);
ylabel('LD1');
title('Class separation for 1D');
legend('Mean for black','Mean for car','Project for black','Project for car');
set(gca,'FontSize',15);
sgtitle('3D data LDA for the black foam and the car sponge');
%% Question 1.d
% Repeat the previous experiment, the only change is that in the
% "Standarize the data" we wse other objects' data
data_PV=[steel_PVT(1:2,:),kitchen_PVT(1:2,:)];
data_PT=[steel_PVT([1 3],:),kitchen_PVT([1 3],:)];
data_VT=[steel_PVT(2:3,:),kitchen_PVT(2:3,:)];
data_PVT=[steel_PVT(1:3,:),kitchen_PVT(1:3,:)];
%  Sandardize the data
% For Pressure and Vibration
for iDim=1:nDim_2D
   data_PV(iDim,:)=(data_PV(iDim,:)-mean(data_PV(iDim,:)))/std(data_PV(iDim,:)); 
end
% For Pressure and Temperature
for iDim=1:nDim_2D
   data_PT(iDim,:)=(data_PT(iDim,:)-mean(data_PT(iDim,:)))/std(data_PT(iDim,:)); 
end
% For Vibration and Temperature
for iDim=1:nDim_2D
   data_VT(iDim,:)=(data_VT(iDim,:)-mean(data_VT(iDim,:)))/std(data_VT(iDim,:)); 
end
for iDim=1:nDim_3D
   data_PVT(iDim,:)=(data_PVT(iDim,:)-mean(data_PVT(iDim,:)))/std(data_PVT(iDim,:)); 
end
%  Calculate Group Mean
% For Pressure and Vibration
m1_PV=mean(data_PV(1:nDim_2D,1:nTrial),2);
m2_PV=mean(data_PV(1:nDim_2D,1+nTrial:2*nTrial),2);
mean_total_PV=m1_PV+m2_PV;
% For Pressure and Temperature
m1_PT=mean(data_PT(1:nDim_2D,1:nTrial),2);
m2_PT=mean(data_PT(1:nDim_2D,1+nTrial:2*nTrial),2);
mean_total_PT=m1_PT+m2_PT;
% For Vibration and Temperature
m1_VT=mean(data_VT(1:nDim_2D,1:nTrial),2);
m2_VT=mean(data_VT(1:nDim_2D,1+nTrial:2*nTrial),2);
mean_total_VT=m1_VT+m2_VT;
% For PVT data
mean_black=mean(data_PVT(1:nDim_3D,1:nTrial),2);
mean_car=mean(data_PVT(1:nDim_3D,1+nTrial:2*nTrial),2);
mean_tatal=mean_car+mean_black;
% Get Scatter Matrices
% Scatter matrices within and between class
% For Pressure and Vibration
Sw1_PV=(data_PV(1:nDim_2D,1:nTrial)-m1_PV)*(data_PV(1:nDim_2D,1:nTrial)-m1_PV)';
Sw2_PV=(data_PV(1:nDim_2D,1+nTrial:2*nTrial)-m2_PV)*(data_PV(1:nDim_2D,1+nTrial:2*nTrial)-m2_PV)';
Sw_PV=Sw1_PV+Sw2_PV;
Sb_PV=(m1_PV-m2_PV)*(m1_PV-m2_PV)';
Scatter_matrix_PV=pinv(Sw_PV)*Sb_PV;
% For Pressure and Temperature
Sw1_PT=(data_PT(1:nDim_2D,1:nTrial)-m1_PT)*(data_PT(1:nDim_2D,1:nTrial)-m1_PT)';
Sw2_PT=(data_PT(1:nDim_2D,1+nTrial:2*nTrial)-m2_PT)*(data_PT(1:nDim_2D,1+nTrial:2*nTrial)-m2_PT)';
Sw_PT=Sw1_PT+Sw2_PT;
Sb_PT=(m1_PT-m2_PT)*(m1_PT-m2_PT)';
Scatter_matrix_PT=pinv(Sw_PT)*Sb_PT;
% For Vibration and Temperature
Sw1_VT=(data_VT(1:nDim_2D,1:nTrial)-m1_VT)*(data_VT(1:nDim_2D,1:nTrial)-m1_VT)';
Sw2_VT=(data_VT(1:nDim_2D,1+nTrial:2*nTrial)-m2_VT)*(data_VT(1:nDim_2D,1+nTrial:2*nTrial)-m2_VT)';
Sw_VT=Sw1_VT+Sw2_VT;
Sb_VT=(m1_VT-m2_VT)*(m1_VT-m2_VT)';
Scatter_matrix_VT=pinv(Sw_VT)*Sb_VT;
% For 3D PVT data
Sw_black=(data_PVT(1:nDim_3D,1:nTrial)-mean_black)*(data_PVT(1:nDim_3D,1:nTrial)-mean_black)';
Sw_car=(data_PVT(1:nDim_3D,1+nTrial:2*nTrial)-mean_car)*(data_PVT(1:nDim_3D,1+nTrial:2*nTrial)-mean_car)';
Sw=Sw_black+Sw_car;
Sb=(mean_black-mean_car)*(mean_black-mean_car)';
Scatter_matrix=pinv(Sw)*Sb;
%  Take the Eigenvalues and Eigenvectors
[eig_vector_PV,eig_value_PV]=eig(Scatter_matrix_PV);
[eig_vector_PT,eig_value_PT]=eig(Scatter_matrix_PT);
[eig_vector_VT,eig_value_VT]=eig(Scatter_matrix_VT);
% Find the largest eigenvalues and its eigenvector
% For Pressure and Vibration
[~,position_PV]=sort(diag(eig_value_PV),'descend');
feature_PV=eig_vector_PV(:,position_PV(1));
% For Pressure and Temperature
[~,position_PT]=sort(diag(eig_value_PT),'descend');
feature_PT=eig_vector_PT(:,position_PT(1));
% For Vibration and Temperature
[~,position_VT]=sort(diag(eig_value_VT),'descend');
feature_VT=eig_vector_VT(:,position_VT(1));
% For 3D PVT data
[eig_vector,eig_value]=eig(Scatter_matrix);
[~,position]=sort(diag(eig_value),'descend');
feature_first=eig_vector(:,position(1));
feature_second=eig_vector(:,position(2));
figure(3);
subplot(2,3,1);
% For Pressure and Vibration
slope=[(feature_PV(2)-0)/(feature_PV(1)-0);(feature_PT(2)-0)/(feature_PT(1)-0);(feature_VT(2)-0)/(feature_VT(1)-0)];
bias=0;
scatter(data_PV(1,1:nTrial),data_PV(2,1:nTrial),'k','filled');
hold on;
scatter(data_PV(1,1+nTrial:2*nTrial),data_PV(2,1+nTrial:2*nTrial),'m','filled');
hold on;
scatter(m1_PV(1),m1_PV(2),180,'k','h','filled');
hold on;
scatter(m2_PV(1),m2_PV(2),180,'m','h','filled');
hold on;
% Plot LDA line and disctimination line
hline1_PV=refline(1*slope(1),bias);
hline1_PV.Color='k';
hline1_PV.LineStyle='-';
hline1_PV.LineWidth=1;
hold on;
hline2_PV=refline(-1/slope(1),bias);
hline2_PV.Color='r';
hline2_PV.LineWidth=1;
hline2_PV.LineStyle=':';
grid on;
axis([-3 3 -3 3]);
axis square;
set(gca,'FontSize',12);
xlabel('Pressure');
ylabel('Vibration');
legend('steel vase','kitchen sponge','mean for steel vase','mean for kitchen sponge','LDA line','disctimination line');
title('2D LDA for Pressure and Vibration');
% For Pressure and Temperature
subplot(2,3,2);
scatter(data_PT(1,1:nTrial),data_PT(2,1:nTrial),'k','filled');
hold on;
scatter(data_PT(1,1+nTrial:2*nTrial),data_PT(2,1+nTrial:2*nTrial),'m','filled');
hold on;
scatter(m1_PT(1),m1_PT(2),180,'k','h','filled');
hold on;
scatter(m2_PT(1),m2_PT(2),180,'m','h','filled');
hold on;
% Plot LDA line and disctimination line
hline1_PT=refline(1*slope(2),bias);
hline1_PT.Color='k';
hline1_PT.LineStyle='-';
hline1_PT.LineWidth=1;
hold on;
hline2_PT=refline(-1/slope(2),bias);
hline2_PT.Color='r';
hline2_PT.LineWidth=1;
hline2_PT.LineStyle=':';
grid on;
axis([-3 3 -3 3]);
axis square;
title('2D LDA for Pressure and Temperature')
xlabel('Pressure');
ylabel('Temperature');
set(gca,'FontSize',12);
% For Vibration and Temperature
subplot(2,3,3);
scatter(data_VT(1,1:nTrial),data_VT(2,1:nTrial),'k','filled');
hold on;
scatter(data_VT(1,1+nTrial:2*nTrial),data_VT(2,1+nTrial:2*nTrial),'m','filled');
hold on;
scatter(m1_VT(1),m1_VT(2),180,'k','h','filled');
hold on;
scatter(m2_VT(1),m2_VT(2),180,'m','h','filled');
hold on;
% Plot LDA line and disctimination line
hline1_VT=refline(1*slope(3),bias);
hline1_VT.Color='k';
hline1_VT.LineStyle='-';
hline1_VT.LineWidth=1;
hold on;
hline2_VT=refline(-1/slope(3),bias);
hline2_VT.Color='r';
hline2_VT.LineWidth=1;
hline2_VT.LineStyle=':';
grid on;
axis([-3 3 -3 3]);
axis square;
xlabel('Vibration');
ylabel('Temperature');
title('2D LDA for Vibration and Temperature')
% legend('steel vase','kitchen sponge','mean for steel vase','mean for kitchen sponge','LDA line','disctimination line');
set(gca,'FontSize',12);
% 1D LDA 
% For Pressure and Vibration
subplot(2,3,4);
project_PV=feature_PV'*data_PV;
m1_PV_1D=feature_PV'*m1_PV;
m2_PV_1D=feature_PV'*m2_PV;
scatter(project_PV(1,1:nTrial),zeros(1,10),'k','filled');
hold on;
scatter(project_PV(1,1+nTrial:2*nTrial),zeros(1,10),'m','filled');
grid on;
scatter(m1_PV_1D,0,180,'k','h','filled');
hold on;
scatter(m2_PV_1D,0,180,'m','h','filled');
hold on
line([0 0],[-2 2],'linestyle','--', 'Color','r', 'LineWidth', 2);
ylabel('LD1');
legend('steel vase','kitchen sponge','mean for steel vase','mean for kitchen sponge','disctimination line');
title('1D LDA for Pressure and Vibration');
set(gca,'FontSize',12);
% For Pressure and Temperature
subplot(2,3,5);
project_PT=feature_PT'*data_PT;
m1_PT_1D=feature_PT'*m1_PT;
m2_PT_1D=feature_PT'*m2_PT;
scatter(project_PT(1,1:nTrial),zeros(1,10),'k','filled');
hold on;
scatter(project_PT(1,1+nTrial:2*nTrial),zeros(1,10),'m','filled');
grid on;
scatter(m1_PT_1D,0,180,'k','h','filled');
hold on;
scatter(m2_PT_1D,0,180,'m','h','filled');
hold on
line([0 0],[-2 2],'linestyle','--', 'Color','r', 'LineWidth', 2);
ylabel('LD1');
title('1D LDA for Pressure and Temperature');
set(gca,'FontSize',12);
% For Vibration and Temperature
subplot(2,3,6);
project_VT=feature_VT'*data_VT;
m1_VT_1D=feature_VT'*m1_VT;
m2_VT_1D=feature_VT'*m2_VT;
scatter(project_VT(1,1:nTrial),zeros(1,10),'k','filled');
hold on;
scatter(project_VT(1,1+nTrial:2*nTrial),zeros(1,10),'m','filled');
grid on;
scatter(m1_VT_1D,0,180,'k','h','filled');
hold on;
scatter(m2_VT_1D,0,180,'m','h','filled');
hold on
line([0 0],[-2 2],'linestyle','--', 'Color','r', 'LineWidth', 2);
ylabel('LD1');
title('1D LDA for Vibration and Temperature');
set(gca,'FontSize',12);
figure(4);
X=[feature_first(1),feature_second(1),-feature_first(1),-feature_second(1)];X=2*X;
Y=[feature_first(2),feature_second(2),-feature_first(2),-feature_second(2)];Y=2*Y;
Z=[feature_first(3),feature_second(3),-feature_first(3),-feature_second(3)];Z=2*Z;
subplot(2,2,1);
scatter3(mean_black(1),mean_black(2),mean_black(3),180,'k','h','filled');
view([60,15])
hold on
scatter3(mean_car(1),mean_car(2),mean_car(3),180,'m','h','filled');
hold on;
scatter3(data_PVT(1,1:nTrial),data_PVT(2,1:nTrial),data_PVT(3,1:nTrial),'k','filled')
hold on;
scatter3(data_PVT(1,1+nTrial:2*nTrial),data_PVT(2,1+nTrial:2*nTrial),data_PVT(3,1+nTrial:2*nTrial),'m','filled')
hold on;
line1=plot3([-feature_first(1)*2,feature_first(1)*2],[-feature_first(2)*2,feature_first(2)*2],[-feature_first(3)*2,feature_first(3)*2]);
line1.Color='red';
line1.LineWidth=1;
line1.LineStyle='-';
hold on;
line2=plot3([-feature_second(1)*2,feature_second(1)*2],[-feature_second(2)*2,feature_second(2)*2],[-feature_second(3)*2,feature_second(3)*2]);
line2.Color='green';
line2.LineWidth=1;
line2.LineStyle='--';
hold on;
patch('X',X,'Y',Y,'Z',Z,'FaceAlpha','0.5');
hold on;
scatter3(0,0,0,'filled','k')
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
legend('Mean for steel','Mean for kitchen','Ten trials for steel','Ten trials for kitchen','LDA line','disctimination line','hyperplane')
subplot(2,2,2);
scatter3(mean_black(1),mean_black(2),mean_black(3),180,'k','h','filled');
view([-10,20])
hold on
scatter3(mean_car(1),mean_car(2),mean_car(3),180,'m','h','filled');
hold on;
scatter3(data_PVT(1,1:nTrial),data_PVT(2,1:nTrial),data_PVT(3,1:nTrial),'k','filled')
hold on;
scatter3(data_PVT(1,1+nTrial:2*nTrial),data_PVT(2,1+nTrial:2*nTrial),data_PVT(3,1+nTrial:2*nTrial),'m','filled')
hold on;
line1=plot3([-feature_first(1)*2,feature_first(1)*2],[-feature_first(2)*2,feature_first(2)*2],[-feature_first(3)*2,feature_first(3)*2]);
line1.Color='red';
line1.LineWidth=1;
line1.LineStyle='-';
hold on;
line2=plot3([-feature_second(1)*2,feature_second(1)*2],[-feature_second(2)*2,feature_second(2)*2],[-feature_second(3)*2,feature_second(3)*2]);
line2.Color='green';
line2.LineWidth=1;
line2.LineStyle='--';
hold on;
patch('X',X,'Y',Y,'Z',Z,'FaceAlpha','0.5');
hold on;
scatter3(0,0,0,'filled','k')
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
legend('Mean for steel','Mean for kitchen','Ten trials for steel','Ten trials for kitchen','LDA line','disctimination line','hyperplane');
% 2D class separation
feature=[feature_first,feature_second];
mean_black_2D=feature'*mean_black;
mean_car_2D=feature'*mean_car;
subplot(2,2,3);
scatter(mean_black_2D(1),mean_black_2D(2),180,'k','h','filled');
hold on;
scatter(mean_car_2D(1),mean_car_2D(2),180,'m','h','filled');
hold on;
feature=[feature_first,feature_second];
project_2D=feature'*data_PVT;
scatter(project_2D(1,1:nTrial),project_2D(2,1:nTrial),'k','filled');
hold on;
scatter(project_2D(1,1+nTrial:2*nTrial),project_2D(2,1+nTrial:2*nTrial),'m','filled');
grid on;
hold on;
line([0 0],[-3 2],'linestyle','--', 'Color','g', 'LineWidth', 2)
xlabel('LD1');  
ylabel('LD2');
title('Class separation for 2D');
legend('Mean for steel','Mean for kitchen','Project for steel','Project for kitchen','disctimination line');
% 1D class separation
mean_black_1D=feature_first'*mean_black;
mean_car_1D=feature_first'*mean_car;
project_1D=feature_first'*data_PVT;
subplot(2,2,4);
scatter(mean_black_1D,0,180,'k','h','filled');
hold on;
scatter(mean_car_1D,0,180,'m','h','filled');
hold on
scatter(project_1D(1,1:nTrial),zeros(1,10),'k','filled');
hold on;
scatter(project_1D(1,1+nTrial:2*nTrial),zeros(1,10),'m','filled');
grid on;
line([0 0],[-2 2],'linestyle','--', 'Color','g', 'LineWidth', 2);
ylabel('LD1');
title('Class separation for 1D');
legend('Mean for steel','Mean for kitchen','Project for steel','Project for kitchen','disctimination line');
sgtitle('3D data LDA for Steel Vase and Kitchen Sponge');