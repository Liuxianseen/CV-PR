%% Section A. Data Preparation
% Author: Yibing Liu, Junyu Yan
%--------------------------------------------------------------------------

clc;clear;close all;
%% Load data
acry_trial1=load('acrylic_211_01_HOLD.mat');
acry_trial2=load('acrylic_211_02_HOLD.mat');
acry_trial3=load('acrylic_211_03_HOLD.mat');
acry_trial4=load('acrylic_211_04_HOLD.mat');
acry_trial5=load('acrylic_211_05_HOLD.mat');
acry_trial6=load('acrylic_211_06_HOLD.mat');
acry_trial7=load('acrylic_211_07_HOLD.mat');
acry_trial8=load('acrylic_211_08_HOLD.mat');
acry_trial9=load('acrylic_211_09_HOLD.mat');
acry_trial10=load('acrylic_211_10_HOLD.mat');
black_trial1=load('black_foam_110_01_HOLD.mat');
black_trial2=load('black_foam_110_02_HOLD.mat');
black_trial3=load('black_foam_110_03_HOLD.mat');
black_trial4=load('black_foam_110_04_HOLD.mat');
black_trial5=load('black_foam_110_05_HOLD.mat');
black_trial6=load('black_foam_110_06_HOLD.mat');
black_trial7=load('black_foam_110_07_HOLD.mat');
black_trial8=load('black_foam_110_08_HOLD.mat');
black_trial9=load('black_foam_110_09_HOLD.mat');
black_trial10=load('black_foam_110_10_HOLD.mat');
car_trial1=load('car_sponge_101_01_HOLD.mat');
car_trial2=load('car_sponge_101_02_HOLD.mat');
car_trial3=load('car_sponge_101_03_HOLD.mat');
car_trial4=load('car_sponge_101_04_HOLD.mat');
car_trial5=load('car_sponge_101_05_HOLD.mat');
car_trial6=load('car_sponge_101_06_HOLD.mat');
car_trial7=load('car_sponge_101_07_HOLD.mat');
car_trial8=load('car_sponge_101_08_HOLD.mat');
car_trial9=load('car_sponge_101_09_HOLD.mat');
car_trial10=load('car_sponge_101_10_HOLD.mat');
flour_trial1=load('flour_sack_410_01_HOLD.mat');
flour_trial2=load('flour_sack_410_02_HOLD.mat');
flour_trial3=load('flour_sack_410_03_HOLD.mat');
flour_trial4=load('flour_sack_410_04_HOLD.mat');
flour_trial5=load('flour_sack_410_05_HOLD.mat');
flour_trial6=load('flour_sack_410_06_HOLD.mat');
flour_trial7=load('flour_sack_410_07_HOLD.mat');
flour_trial8=load('flour_sack_410_08_HOLD.mat');
flour_trial9=load('flour_sack_410_09_HOLD.mat');
flour_trial10=load('flour_sack_410_10_HOLD.mat');
kitchen_trial1=load('kitchen_sponge_114_01_HOLD.mat');
kitchen_trial2=load('kitchen_sponge_114_02_HOLD.mat');
kitchen_trial3=load('kitchen_sponge_114_03_HOLD.mat');
kitchen_trial4=load('kitchen_sponge_114_04_HOLD.mat');
kitchen_trial5=load('kitchen_sponge_114_05_HOLD.mat');
kitchen_trial6=load('kitchen_sponge_114_06_HOLD.mat');
kitchen_trial7=load('kitchen_sponge_114_07_HOLD.mat');
kitchen_trial8=load('kitchen_sponge_114_08_HOLD.mat');
kitchen_trial9=load('kitchen_sponge_114_09_HOLD.mat');
kitchen_trial10=load('kitchen_sponge_114_10_HOLD.mat');
steel_trial1=load('steel_vase_702_01_HOLD.mat');
steel_trial2=load('steel_vase_702_02_HOLD.mat');
steel_trial3=load('steel_vase_702_03_HOLD.mat');
steel_trial4=load('steel_vase_702_04_HOLD.mat');
steel_trial5=load('steel_vase_702_05_HOLD.mat');
steel_trial6=load('steel_vase_702_06_HOLD.mat');
steel_trial7=load('steel_vase_702_07_HOLD.mat');
steel_trial8=load('steel_vase_702_08_HOLD.mat');
steel_trial9=load('steel_vase_702_09_HOLD.mat');
steel_trial10=load('steel_vase_702_10_HOLD.mat');

%% Question1
% Plot pressure, vibration, temperature and electrodes for arcylic for
% finger 0 
% The time step index
time = 1:1:length(acry_trial1.F0pdc);
% Plot the pressure of acrylic for 1 trial
subplot(4,1,1);
plot(time, acry_trial1.F0pdc,'linewidth',2);
hold on;
plot(time, black_trial1.F0pdc,'linewidth',2);
hold on;
plot(time, car_trial1.F0pdc,'linewidth',2);
hold on;
plot(time, flour_trial1.F0pdc,'linewidth',2);
hold on;
plot(time, kitchen_trial1.F0pdc,'linewidth',2);
hold on;
plot(time, steel_trial1.F0pdc,'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Pressure of 6 objects for trial 1 (F0)');
xlabel('Time step index');
ylabel('Presseure');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');

% Plot the vibrations of acrylic for 1 trial
subplot(4,1,2);
plot(time, acry_trial1.F0pac(2,:),'linewidth',2);
hold on;
plot(time, black_trial1.F0pac(2,:),'linewidth',2);
hold on;
plot(time, car_trial1.F0pac(2,:),'linewidth',2);
hold on;
plot(time, flour_trial1.F0pac(2,:),'linewidth',2);
hold on;
plot(time, kitchen_trial1.F0pac(2,:),'linewidth',2);
hold on;
plot(time, steel_trial1.F0pac(2,:),'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Vibration of 6 objects for trial 1 (F0)');
xlabel('Time step index');
ylabel('Vibration');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the tempreture of acrylic for 1 trial
subplot(4,1,3);
plot(time, acry_trial1.F0tdc,'linewidth',2);
hold on;
plot(time, black_trial1.F0tdc,'linewidth',2);
hold on;
plot(time, car_trial1.F0tdc,'linewidth',2);
hold on;
plot(time, flour_trial1.F0tdc,'linewidth',2);
hold on;
plot(time, kitchen_trial1.F0tdc,'linewidth',2);
hold on;
plot(time, steel_trial1.F0tdc,'linewidth',2);
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Temperature of 6 objects for trial 1 (F0)');
xlabel('Time step index');
ylabel('Temperature');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the electrodes of acrylic for 1 trial
subplot(4,1,4);
plot(time, mean(acry_trial1.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(black_trial1.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(car_trial1.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(flour_trial1.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(kitchen_trial1.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(steel_trial1.F0Electrodes,1),'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Electrode of 6 objects for trial 1 (F0)');
xlabel('Time step index');
ylabel('Electrode');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');

% Plot pressure, vibration, temperature and electrodes for arcylic for
% finger 1
figure;
% The time step index
time = 1:1:length(acry_trial1.F1pdc);
% Plot the pressure of acrylic for 1 trial
subplot(4,1,1);
plot(time, acry_trial1.F1pdc,'linewidth',2);
hold on;
plot(time, black_trial1.F1pdc,'linewidth',2);
hold on;
plot(time, car_trial1.F1pdc,'linewidth',2);
hold on;
plot(time, flour_trial1.F1pdc,'linewidth',2);
hold on;
plot(time, kitchen_trial1.F1pdc,'linewidth',2);
hold on;
plot(time, steel_trial1.F1pdc,'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
hold on;
grid on; grid minor;
title('Pressure of 6 objects for trial 1 (F1)');
xlabel('Time step index');
ylabel('Presseure');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the vibrations of acrylic for 1 trial
subplot(4,1,2);
plot(time, acry_trial1.F1pac(2,:),'linewidth',2);
hold on;
plot(time, black_trial1.F1pac(2,:),'linewidth',2);
hold on;
plot(time, car_trial1.F1pac(2,:),'linewidth',2);
hold on;
plot(time, flour_trial1.F1pac(2,:),'linewidth',2);
hold on;
plot(time, kitchen_trial1.F1pac(2,:),'linewidth',2);
hold on;
plot(time, steel_trial1.F1pac(2,:),'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Vibration of 6 objects for trial 1 (F1)');
xlabel('Time step index');
ylabel('Vibration');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the tempreture of acrylic for 1 trial
subplot(4,1,3);
plot(time, acry_trial1.F1tdc,'linewidth',2);
hold on;
plot(time, black_trial1.F1tdc,'linewidth',2);
hold on;
plot(time, car_trial1.F1tdc,'linewidth',2);
hold on;
plot(time, flour_trial1.F1tdc,'linewidth',2);
hold on;
plot(time, kitchen_trial1.F1tdc,'linewidth',2);
hold on;
plot(time, steel_trial1.F1tdc,'linewidth',2);
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Temperature of 6 objects for trial 1 (F1)');
xlabel('Time step index');
ylabel('Temperature');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the electrodes of acrylic for 1 trial
subplot(4,1,4);
plot(time, mean(acry_trial1.F1Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(black_trial1.F1Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(car_trial1.F1Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(flour_trial1.F1Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(kitchen_trial1.F1Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(steel_trial1.F1Electrodes,1),'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Electrode of 6 objects for trial 1 (F1)');
xlabel('Time step index');
ylabel('Electrode');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');

% Plot pressure, vibration, temperature and electrodes for arcylic for
% finger 0 trial 2
figure;
% The time step index
time = 1:1:length(acry_trial2.F0pdc);
% Plot the pressure of acrylic for trial 2
subplot(4,1,1);
plot(time, acry_trial2.F0pdc,'linewidth',2);
hold on;
plot(time, black_trial2.F0pdc,'linewidth',2);
hold on;
plot(time, car_trial2.F0pdc,'linewidth',2);
hold on;
plot(time, flour_trial2.F0pdc,'linewidth',2);
hold on;
plot(time, kitchen_trial2.F0pdc,'linewidth',2);
hold on;
plot(time, steel_trial2.F0pdc,'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
hold on;
set(gca,'fontsize',10);
grid on; grid minor;
title('Pressure of 6 objects for trial 2 (F0)');
xlabel('Time step index');
ylabel('Presseure');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the vibrations of acrylic for 1 trial
subplot(4,1,2);
plot(time, acry_trial2.F0pac(2,:),'linewidth',2);
hold on;
plot(time, black_trial2.F0pac(2,:),'linewidth',2);
hold on;
plot(time, car_trial2.F0pac(2,:),'linewidth',2);
hold on;
plot(time, flour_trial2.F0pac(2,:),'linewidth',2);
hold on;
plot(time, kitchen_trial2.F0pac(2,:),'linewidth',2);
hold on;
plot(time, steel_trial2.F0pac(2,:),'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Vibration of 6 objects for trial 2 (F0)');
xlabel('Time step index');
ylabel('Vibration');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the tempreture of acrylic for 1 trial
subplot(4,1,3);
plot(time, acry_trial2.F0tdc,'linewidth',2);
hold on;
plot(time, black_trial2.F0tdc,'linewidth',2);
hold on;
plot(time, car_trial2.F0tdc,'linewidth',2);
hold on;
plot(time, flour_trial2.F0tdc,'linewidth',2);
hold on;
plot(time, kitchen_trial2.F0tdc,'linewidth',2);
hold on;
plot(time, steel_trial2.F0tdc,'linewidth',2);
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Temperature of 6 objects for trial 2 (F0)');
xlabel('Time step index');
ylabel('Temperature');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
% Plot the electrodes of acrylic for 1 trial
subplot(4,1,4);
plot(time, mean(acry_trial2.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(black_trial2.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(car_trial2.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(flour_trial2.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(kitchen_trial2.F0Electrodes,1),'linewidth',2);
hold on;
plot(time, mean(steel_trial2.F0Electrodes,1),'linewidth',2);
hold on;
xline(15,'--k','Selected','LineWidth',2);
set(gca,'fontsize',10);
grid on; grid minor;
title('Electrode of 6 objects for trial 2 (F0)');
xlabel('Time step index');
ylabel('Electrode');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');

%% Question2
% Sample the Pressure, Vibration and Temperature into scalar
% The time index
tIndex = 22;
% The number of trial
nTrial = 10;
% The number of objects
nObj = 6;
% The number of parameters as: P, V, T
nPara_PVT = 3;
% The object name
object_name = {'acry','black','car','flour','kitchen','steel'};
% Sample the data
PVT_name = cell(1,nObj);
for iObj = 1:nObj
    PVT = zeros(nPara_PVT,nTrial);
    for iTrial = 1:nTrial
        object_trial = [object_name{iObj},'_trial',num2str(iTrial)];
        pressure = eval(object_trial).F0pdc(1,tIndex);
        vibration = eval(object_trial).F0pac(2,tIndex);
        temp = eval(object_trial).F0tdc(1,tIndex);
        PVT(1:nPara_PVT,iTrial) = [pressure, vibration, temp]; 
    end
    PVT_name{1,iObj}= [object_name{iObj},'_PVT'];
    eval([PVT_name{iObj},'= PVT']);
end
save('F0_PVT.mat',PVT_name{1,1:nObj});

%% Sample the Electrode data into scalar
% The time index
tIndex = 22;
% The number of trial
nTrial = 10;
% The number of objects
nObj = 6;
% The number of parameters as: 19 electrode
nPara_Elec = 19;
% The object name
object_name = {'acry','black','car','flour','kitchen','steel'};
% Sample the data
Elec_name = cell(1,nObj);
for iObj = 1:nObj
    Elec = zeros(nPara_Elec,nTrial);
    for iTrial = 1:nTrial
        object_trial = [object_name{iObj},'_trial',num2str(iTrial)];
        Electrode = eval(object_trial).F0Electrodes(:,tIndex);
        Elec(1:nPara_Elec,iTrial) = Electrode; 
    end
    Elec_name{1,iObj}= [object_name{iObj},'_Electrode'];
    eval([Elec_name{iObj},'= Elec']);
end
save('F0_Electrode.mat',Elec_name{1,1:nObj});

%% Question3
% Load data
load('F0_PVT.mat');
% Initialization
nObj = 6;
% The object name
object_name = {'acry','black','car','flour','kitchen','steel'};
% The color for objects
color = {'r','g','b','c','m','k'};
% Create a 3D scatter plot
figure;
for iObj = 1:nObj
    data = [object_name{iObj},'_PVT'];
    data = eval(data);
    x_axis = data(1,:);
    y_axis = data(2,:);
    z_axis = data(3,:);
    scatter3(x_axis,y_axis,z_axis,color{iObj},'filled');
    hold on;
end
xlabel('Pressure');
ylabel('Vibration');
zlabel('Temperature');
legend('acrylic','black\_foam','car\_sponge','flour\_sack','kitchen\_sponge','steel\_vase');
title('The 3D scatter plot of the PVT');
set(gca,'fontsize',12);







